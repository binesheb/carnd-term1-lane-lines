
# Color Selection Code for Lane Lines Detection

## Importing Libraries


```python
#import all the basic libraries required

#matplotlib.pyplot > Provides a MATLAB-like plotting framework. pylab combines pyplot with numpy into a single namespace. 
import matplotlib.pyplot as plt 
#This is further referef as 'plt' for convenience

#matplotlib.image > Provides operations for importing images including metadata from them
import matplotlib.image as mpimg 
#This is further refered as 'mpimg' for convenience

#NumPy is the fundamental package for scientific computing with Python. 
#It contains among other things: a powerful N-dimensional array object sophisticated (broadcasting) functions etc.
import numpy as np 
#This is further refered as 'np'
```


## import a sample image and print some stats


```python
#we have a image file 'prog1.jpg' in same directory
image=mpimg.imread('prog1.jpg')

#now onwards we can refer prog1.jpg as a multi dimensional array named 'image'


```

## Display the image along with some of its metadata resources


```python
## First the image imported shall be displayed to ensure the import was successful
plt.imshow(image) #we have imported our prog1.jpg to the array named image

#after the end of previuos command the image is exported to the display buffer. Now we will display the image
```




    <matplotlib.image.AxesImage at 0x1ec82f80e80>




```python
#after the end of previuos command the image is exported to the display buffer. Now we will display the image
print ('The Original image:')
plt.show() #this command will display the content in the display buffer.
#This will execute only along with a previuos command which writes something into the buffer
```

    The Original image:
    


![png](output_7_1.png)


## displaying the metadata informations


```python
#image type is stored in type(image), dimensions is a 2D array in image.shape as ysize,xsize
print('This image is: ',type(image), 'with dimensions:', image.shape)

```

    This image is:  <class 'numpy.ndarray'> with dimensions: (540, 960, 3)
    

## obtaining specific metadata like image dimensions


```python
ysize=image.shape[0] #ysize
xsize=image.shape[1] #xsize

print('This image has following dimensions')
print('Height :', ysize, 'pixels') #display ysize
print('Width  :', xsize, 'pixels') #display xsize

```

    This image has following dimensions
    Height : 540 pixels
    Width  : 960 pixels
    

## Create a temporary copy to work upon our logics


```python
temp_img=np.copy(image) #now temp_img will have same information as original image
```


```python
plt.imshow(temp_img) #write the image to display buffer
plt.show() #display everything from display buffer
```


![png](output_14_0.png)


## Filter definition for Color threshold


```python
#To define a Filter parameters, we create a array which holds all the parameters

red_threshold = 200
green_threshold = 200
blue_threshold = 200
rgb_threshold = [red_threshold, green_threshold, blue_threshold] 

#Now rgb_threshold can be used as a filter function to obtain the parameters
```

## Identification of pixels which are under the threshold values


```python
# temp_img[:,:,0] represent RED Channel, 1 > GREEN , 2 > BLUE
threshold_img = (temp_img[:,:,0] < rgb_threshold[0]) |  (temp_img[:,:,1] < rgb_threshold[1]) | (temp_img[:,:,2] < rgb_threshold[2])

plt.imshow(threshold_img)
plt.show()
```


![png](output_18_0.png)


## Now we will convert every positively returned pixel to black [0,0,0]


```python
temp_img[threshold_img] = [0,0,0]
plt.imshow(temp_img)
plt.show()
```


![png](output_20_0.png)


## Save the image


```python
# Save the image temp_img to a file
# mpimg.imsave("prog1-result.jpg", temp_img) 
```

## End of Program
